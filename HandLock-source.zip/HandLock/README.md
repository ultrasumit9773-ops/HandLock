# HandLock (Android)

A starter Android app that uses the front camera and MediaPipe Gesture Recognizer. When it detects the built-in `Open_Palm` gesture, it asks Android to lock the screen using the Device Admin API.

## Important limitations
- This starter detects gestures only while the app is open and the camera preview is running. Android restricts camera use in the background; this project does not secretly run the camera in the background.
- You must manually enable the app's screen-lock / Device Admin permission in Android settings when prompted.
- Test carefully: showing an open palm may lock your phone. To stop detection, tap **Stop camera** before showing the gesture.
- This source project has not been built/tested on the target phone in this environment.

## Build an APK

### Recommended: GitHub Actions (works from a browser/phone, but needs a GitHub account)
1. Create a new empty repository on GitHub named `HandLock`.
2. Upload all files/folders from this project to the repository (keep their paths, including `.github/workflows/android.yml`).
3. Open the repository's **Actions** tab and allow workflows if asked.
4. Select **Build HandLock APK** and run it, or push a commit to trigger it.
5. Open the completed workflow run and download the `HandLock-debug-apk` artifact. Extract the downloaded ZIP to get `app-debug.apk`.
6. Open the APK on your phone and allow installation if Android asks. Only install builds from your own repository that you trust.

The first build downloads the official MediaPipe gesture model during Gradle's `preBuild` task, so internet access is required.

## Main files
- `app/src/main/java/com/example/handlock/MainActivity.kt`: camera, gesture recognition, lock action.
- `app/src/main/java/com/example/handlock/LockAdminReceiver.kt`: Android Device Admin receiver.
