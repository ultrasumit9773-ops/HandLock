import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.handlock"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.handlock"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

val downloadGestureModel by tasks.registering {
    val outFile = layout.projectDirectory.file("src/main/assets/gesture_recognizer.task")
    outputs.file(outFile)
    doLast {
        val file = outFile.asFile
        if (!file.exists() || file.length() < 100_000) {
            file.parentFile.mkdirs()
            URL("https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task").openStream().use { input -> file.outputStream().use { input.copyTo(it) } }
        }
    }
}
tasks.named("preBuild").configure { dependsOn(downloadGestureModel) }

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.camera:camera-core:1.4.1")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    implementation("androidx.camera:camera-view:1.4.1")
    implementation("com.google.mediapipe:tasks-vision:0.10.21")
}
