package com.example.handlock

import android.app.admin.DeviceAdminReceiver

class LockAdminReceiver : DeviceAdminReceiver()
