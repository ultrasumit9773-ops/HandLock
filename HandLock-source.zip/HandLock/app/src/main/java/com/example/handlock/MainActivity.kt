package com.example.handlock

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.os.SystemClock
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var previewView: PreviewView
    private var recognizer: GestureRecognizer? = null
    private var lastLockAt = 0L
    private var lastGestureAt = 0L
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else status.text = "Camera permission is needed."
    }
    private val adminLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (isAdminActive()) startCamera() else status.text = "Please enable HandLock screen-lock permission, then tap Start."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }
        status = TextView(this).apply { textSize = 18f; text = "HandLock is ready. Enable screen-lock permission first." }
        previewView = PreviewView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        val enableButton = Button(this).apply {
            text = "Enable screen-lock permission"
            setOnClickListener { requestAdmin() }
        }
        val startButton = Button(this).apply {
            text = "Start hand detection"
            setOnClickListener { startIfReady() }
        }
        val stopButton = Button(this).apply {
            text = "Stop camera"
            setOnClickListener { stopCamera(); status.text = "Camera stopped." }
        }
        layout.addView(status)
        layout.addView(enableButton)
        layout.addView(startButton)
        layout.addView(stopButton)
        layout.addView(previewView)
        setContentView(layout)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun isAdminActive(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(ComponentName(this, LockAdminReceiver::class.java))
    }

    private fun requestAdmin() {
        if (isAdminActive()) {
            status.text = "Screen-lock permission is already enabled. Tap Start."
            return
        }
        val component = ComponentName(this, LockAdminReceiver::class.java)
        adminLauncher.launch(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "HandLock needs permission to lock the screen when it detects an open palm.")
        })
    }

    private fun startIfReady() {
        if (!isAdminActive()) { requestAdmin(); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA); return
        }
        startCamera()
    }

    private fun startCamera() {
        try {
            if (recognizer == null) {
                val options = GestureRecognizer.GestureRecognizerOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetPath("gesture_recognizer.task").setDelegate(Delegate.CPU).build())
                    .setRunningMode(RunningMode.LIVE_STREAM)
                    .setResultListener { result: GestureRecognizerResult, _ -> onGestureResult(result) }
                    .setErrorListener { error: RuntimeException -> runOnUiThread { status.text = "Gesture model error: ${error.message}" } }
                    .build()
                recognizer = GestureRecognizer.createFromOptions(this, options)
            }
            val providerFuture = ProcessCameraProvider.getInstance(this)
            providerFuture.addListener({
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    try {
                        val bitmap: Bitmap = imageProxy.toBitmap()
                        val mpImage = BitmapImageBuilder(bitmap).build()
                        val processing = ImageProcessingOptions.builder().setRotationDegrees(imageProxy.imageInfo.rotationDegrees).build()
                        recognizer?.recognizeAsync(mpImage, processing, SystemClock.uptimeMillis())
                    } catch (_: Exception) {
                        // Ignore a single bad frame; the next camera frame will be processed.
                    } finally { imageProxy.close() }
                }
                try {
                    provider.unbindAll()
                    provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
                    runOnUiThread { status.text = "Watching for an open palm. Keep HandLock open. Show ✋ to lock." }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Could not start camera: ${e.message}" }
                }
            }, ContextCompat.getMainExecutor(this))
        } catch (e: Exception) {
            status.text = "Could not start HandLock: ${e.message}"
        }
    }

    private fun onGestureResult(result: GestureRecognizerResult) {
        val now = SystemClock.elapsedRealtime()
        val category = result.gestures().firstOrNull()?.firstOrNull()?.categoryName()
        if (category == "Open_Palm") {
            if (now - lastGestureAt > 900 && now - lastLockAt > 5000) {
                lastGestureAt = now
                lastLockAt = now
                runOnUiThread { status.text = "Open palm detected — locking screen…" }
                previewView.postDelayed({
                    if (isAdminActive()) {
                        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                        dpm.lockNow()
                    }
                }, 700)
            }
        } else if (now - lastLockAt > 1500) {
            runOnUiThread { status.text = "Watching for an open palm. Detected: ${category ?: "no hand"}" }
        }
    }

    private fun stopCamera() {
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Exception) { }
        try { recognizer?.close() } catch (_: Exception) { }
        recognizer = null
    }

    override fun onDestroy() {
        stopCamera()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
